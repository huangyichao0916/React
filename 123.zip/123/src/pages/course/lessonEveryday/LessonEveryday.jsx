import React, { Component } from 'react';

class LessonEveryday extends Component {
    state = {  }
    render() { 
        return (
            <div>
                LessonEveryday
            </div>
        );
    }
}
 
export default LessonEveryday;