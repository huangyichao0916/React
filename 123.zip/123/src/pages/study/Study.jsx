import React, { Component } from 'react';

class Study extends Component {
    state = {  }
    render() { 
        return ( 
            <div>
                study
            </div>
        );
    }
}
 
export default Study;