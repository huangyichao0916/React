import React, { Component } from 'react';

class Discover extends Component {
    state = {  }
    render() { 
        return ( 
            <div>
                discover
            </div>
        );
    }
}
 
export default Discover;